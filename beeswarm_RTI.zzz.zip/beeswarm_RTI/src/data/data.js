// IMPORTANT:
// Total cost values cannot contain ,

export default[
  {    
    "ExpenseProjID": "0162024.200.001.001.002",
    "Org": "01.00093.250",
    "TotalCost": 105.00
  },
  {
    "ExpenseProjID": "0165165.001.114.002",
    "Org": "02.00001.312",
    "TotalCost": 157.00
  },
  {
    "ExpenseProjID": "0165165.500.001",
    "Org": "02.00001.312",
    "TotalCost": 14406.00
  } 
]